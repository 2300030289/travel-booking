
import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useToast } from '@/components/ui/use-toast';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";

type AuthFormProps = {
  isLogin?: boolean;
}

export default function AuthForm({ isLogin = true }: AuthFormProps) {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [name, setName] = useState('');
  const navigate = useNavigate();
  const { toast } = useToast();

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    // In a real app, we'd validate and send this to a server
    // For now, we'll just simulate auth with localStorage
    if (isLogin) {
      // Simple demo login - in a real app, this would validate with a server
      localStorage.setItem('user', JSON.stringify({ email, name: "Demo User" }));
      toast({
        title: "Login successful!",
        description: "Welcome back to TripEase",
      });
      navigate('/dashboard');
    } else {
      // Simple demo registration
      localStorage.setItem('user', JSON.stringify({ email, name }));
      toast({
        title: "Registration successful!",
        description: "Welcome to TripEase",
      });
      navigate('/dashboard');
    }
  };

  return (
    <Card className="w-full max-w-md mx-auto animate-fade-in">
      <CardHeader className="space-y-1">
        <CardTitle className="text-2xl font-bold text-center">
          {isLogin ? 'Login to your account' : 'Create an account'}
        </CardTitle>
        <CardDescription className="text-center">
          {isLogin 
            ? 'Enter your email and password to login' 
            : 'Enter your details to create an account'}
        </CardDescription>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-4">
          {!isLogin && (
            <div className="space-y-2">
              <label htmlFor="name" className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70">
                Full Name
              </label>
              <Input 
                id="name" 
                type="text" 
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="John Doe" 
                required={!isLogin}
              />
            </div>
          )}
          
          <div className="space-y-2">
            <label htmlFor="email" className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70">
              Email
            </label>
            <Input 
              id="email" 
              type="email" 
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="name@example.com" 
              required
            />
          </div>
          
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <label htmlFor="password" className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70">
                Password
              </label>
              {isLogin && (
                <a href="#" className="text-sm text-travel-700 hover:text-travel-600">
                  Forgot password?
                </a>
              )}
            </div>
            <Input 
              id="password" 
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)} 
              required
            />
          </div>
        </form>
      </CardContent>
      <CardFooter className="flex flex-col gap-4">
        <Button 
          type="submit" 
          onClick={handleSubmit}
          className="w-full bg-travel-700 hover:bg-travel-800"
        >
          {isLogin ? 'Login' : 'Sign up'}
        </Button>
        
        <div className="text-center text-sm">
          {isLogin ? (
            <span>
              Don't have an account?{" "}
              <a onClick={() => navigate('/register')} className="text-travel-700 hover:text-travel-600 cursor-pointer">
                Sign up
              </a>
            </span>
          ) : (
            <span>
              Already have an account?{" "}
              <a onClick={() => navigate('/login')} className="text-travel-700 hover:text-travel-600 cursor-pointer">
                Login
              </a>
            </span>
          )}
        </div>
      </CardFooter>
    </Card>
  );
}
