
import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useToast } from '@/hooks/use-toast';
import { Calendar } from "@/components/ui/calendar";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { format } from "date-fns";
import { Calendar as CalendarIcon } from "lucide-react";
import { Label } from "@/components/ui/label";

export default function HotelSearchForm() {
  const [location, setLocation] = useState('');
  const [checkIn, setCheckIn] = useState<Date | undefined>(new Date());
  const [checkOut, setCheckOut] = useState<Date | undefined>(
    new Date(new Date().setDate(new Date().getDate() + 2))
  );
  const [rooms, setRooms] = useState('1');
  const [guests, setGuests] = useState('2');
  
  const navigate = useNavigate();
  const { toast } = useToast();

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!location || !checkIn || !checkOut) {
      toast({
        title: "Missing information",
        description: "Please fill in all required fields",
        variant: "destructive",
      });
      return;
    }
    
    // Navigate to search results with query params
    const searchParams = new URLSearchParams({
      location,
      checkIn: checkIn?.toISOString() || '',
      checkOut: checkOut?.toISOString() || '',
      rooms,
      guests
    });
    
    navigate(`/hotels/search?${searchParams.toString()}`);
  };

  return (
    <div className="travel-card p-6">
      <form onSubmit={handleSearch} className="space-y-6">
        <div className="space-y-2">
          <Label htmlFor="location">Destination/Hotel Name</Label>
          <Input 
            id="location"
            placeholder="Where are you going?" 
            value={location}
            onChange={(e) => setLocation(e.target.value)}
            required
          />
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="space-y-2">
            <Label>Check-in</Label>
            <Popover>
              <PopoverTrigger asChild>
                <Button
                  variant="outline"
                  className="w-full justify-start text-left font-normal"
                >
                  <CalendarIcon className="mr-2 h-4 w-4" />
                  {checkIn ? format(checkIn, "PPP") : <span>Pick a date</span>}
                </Button>
              </PopoverTrigger>
              <PopoverContent className="w-auto p-0">
                <Calendar
                  mode="single"
                  selected={checkIn}
                  onSelect={setCheckIn}
                  initialFocus
                  disabled={(date) => date < new Date()}
                />
              </PopoverContent>
            </Popover>
          </div>
          
          <div className="space-y-2">
            <Label>Check-out</Label>
            <Popover>
              <PopoverTrigger asChild>
                <Button
                  variant="outline"
                  className="w-full justify-start text-left font-normal"
                >
                  <CalendarIcon className="mr-2 h-4 w-4" />
                  {checkOut ? format(checkOut, "PPP") : <span>Pick a date</span>}
                </Button>
              </PopoverTrigger>
              <PopoverContent className="w-auto p-0">
                <Calendar
                  mode="single"
                  selected={checkOut}
                  onSelect={setCheckOut}
                  initialFocus
                  disabled={(date) => 
                    date < new Date() || 
                    (checkIn ? date <= checkIn : false)
                  }
                />
              </PopoverContent>
            </Popover>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="space-y-2">
            <Label htmlFor="rooms">Rooms</Label>
            <select 
              id="rooms" 
              className="w-full p-2 border border-gray-300 rounded-md"
              value={rooms}
              onChange={(e) => setRooms(e.target.value)}
              required
            >
              {[1, 2, 3, 4, 5].map((num) => (
                <option key={num} value={num}>{num} {num === 1 ? 'room' : 'rooms'}</option>
              ))}
            </select>
          </div>
          
          <div className="space-y-2">
            <Label htmlFor="guests">Guests</Label>
            <select 
              id="guests" 
              className="w-full p-2 border border-gray-300 rounded-md"
              value={guests}
              onChange={(e) => setGuests(e.target.value)}
              required
            >
              {[1, 2, 3, 4, 5, 6, 7, 8].map((num) => (
                <option key={num} value={num}>{num} {num === 1 ? 'guest' : 'guests'}</option>
              ))}
            </select>
          </div>
        </div>

        <Button type="submit" className="w-full md:w-auto bg-travel-700 hover:bg-travel-800">
          Search Hotels
        </Button>
      </form>
    </div>
  );
}
