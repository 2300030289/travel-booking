
import React from 'react';
import AppLayout from '@/components/layout/AppLayout';
import CabSearchForm from '@/components/cabs/CabSearchForm';
import { CarTaxiFront } from 'lucide-react';

export default function Cabs() {
  return (
    <AppLayout requireAuth={true}>
      <section className="relative py-12 px-4 md:px-8 overflow-hidden bg-gradient-to-br from-travel-100 via-travel-50 to-white">
        <div className="max-w-6xl mx-auto relative z-10">
          <div className="text-center mb-10">
            <h1 className="text-4xl md:text-5xl font-bold text-gray-900 mb-4">
              Book a Cab
            </h1>
            <p className="text-xl text-gray-700 max-w-2xl mx-auto">
              Reliable cab services for your local and outstation needs
            </p>
          </div>
          
          <div className="bg-white rounded-2xl shadow-lg overflow-hidden">
            <div className="p-1">
              <div className="flex items-center justify-center gap-2 p-4 border-b">
                <CarTaxiFront className="h-5 w-5 text-travel-700" />
                <h2 className="text-xl font-medium">Cab Search</h2>
              </div>
              <CabSearchForm />
            </div>
          </div>
        </div>
      </section>
      
      <section className="py-16 travel-container">
        <h2 className="text-2xl font-bold mb-8 text-center">Our Services</h2>
        
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-6">
          {[
            {
              title: 'Airport Transfer',
              description: 'Comfortable rides to and from airports',
              icon: '✈️'
            },
            {
              title: 'Hourly Rental',
              description: 'Flexible cab service charged per hour',
              icon: '⏱️'
            },
            {
              title: 'Outstation',
              description: 'Intercity travel with experienced drivers',
              icon: '🏙️'
            }
          ].map((service, i) => (
            <div key={i} className="travel-card rounded-xl p-6 text-center transition-all duration-300 hover:shadow-lg">
              <div className="text-4xl mb-4">{service.icon}</div>
              <h3 className="text-xl font-medium mb-2">{service.title}</h3>
              <p className="text-gray-600">{service.description}</p>
            </div>
          ))}
        </div>
        
        <div className="mt-12 bg-travel-50 rounded-xl p-6 md:p-8">
          <div className="flex flex-col md:flex-row items-center justify-between gap-6">
            <div>
              <h3 className="text-xl font-bold mb-2">Business Travel</h3>
              <p className="text-gray-700">Special corporate packages with priority booking and dedicated support</p>
            </div>
            <button className="bg-travel-700 hover:bg-travel-800 text-white px-6 py-3 rounded-lg font-medium">
              Contact for Corporate Rates
            </button>
          </div>
        </div>
      </section>
    </AppLayout>
  );
}
