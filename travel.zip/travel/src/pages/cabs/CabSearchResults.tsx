
import React, { useEffect, useState } from 'react';
import { useSearchParams } from 'react-router-dom';
import AppLayout from '@/components/layout/AppLayout';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { format } from 'date-fns';

interface Cab {
  id: number;
  type: string;
  capacity: number;
  price: number;
  estimatedTime: string;
  provider: string;
  features: string[];
  image: string;
}

export default function CabSearchResults() {
  const [searchParams] = useSearchParams();
  const [cabs, setCabs] = useState<Cab[]>([]);
  const [loading, setLoading] = useState(true);

  const pickup = searchParams.get('pickup') || '';
  const drop = searchParams.get('drop') || '';
  const pickupDate = searchParams.get('pickupDate') ? new Date(searchParams.get('pickupDate')!) : new Date();
  const pickupTime = searchParams.get('pickupTime') || '12:00';
  const tripType = searchParams.get('tripType') || 'oneWay';
  const returnDate = searchParams.get('returnDate') ? new Date(searchParams.get('returnDate')!) : undefined;

  useEffect(() => {
    // Simulate API call with timeout
    setTimeout(() => {
      const mockCabs: Cab[] = [
        {
          id: 1,
          type: "Economy",
          capacity: 4,
          price: tripType === 'oneWay' ? 25 : 45,
          estimatedTime: "30 mins",
          provider: "City Cabs",
          features: ["AC", "GPS Tracking", "Water Bottle"],
          image: "https://placehold.co/200x100"
        },
        {
          id: 2,
          type: "Premium Sedan",
          capacity: 4,
          price: tripType === 'oneWay' ? 35 : 60,
          estimatedTime: "25 mins",
          provider: "Luxury Rides",
          features: ["AC", "WiFi", "Premium Service", "GPS Tracking"],
          image: "https://placehold.co/200x100"
        },
        {
          id: 3,
          type: "SUV",
          capacity: 6,
          price: tripType === 'oneWay' ? 45 : 75,
          estimatedTime: "35 mins",
          provider: "Family Rides",
          features: ["AC", "Spacious", "WiFi", "GPS Tracking"],
          image: "https://placehold.co/200x100"
        },
        {
          id: 4,
          type: "Luxury",
          capacity: 4,
          price: tripType === 'oneWay' ? 60 : 100,
          estimatedTime: "20 mins",
          provider: "Executive Cabs",
          features: ["AC", "Premium Service", "WiFi", "Refreshments", "Professional Driver"],
          image: "https://placehold.co/200x100"
        }
      ];
      setCabs(mockCabs);
      setLoading(false);
    }, 1000);
  }, [pickup, drop, tripType]);

  return (
    <AppLayout requireAuth={true}>
      <div className="py-8 travel-container">
        <h1 className="text-2xl font-bold mb-4">Cabs from {pickup} to {drop}</h1>
        <div className="mb-6">
          <div className="flex flex-wrap gap-2 text-sm">
            <span className="bg-travel-100 text-travel-800 px-2 py-1 rounded-md">
              Pickup: {format(pickupDate, "PPP")} at {pickupTime}
            </span>
            <span className="bg-travel-100 text-travel-800 px-2 py-1 rounded-md">
              {tripType === 'oneWay' ? 'One Way' : 'Round Trip'}
            </span>
            {tripType === 'roundTrip' && returnDate && (
              <span className="bg-travel-100 text-travel-800 px-2 py-1 rounded-md">
                Return: {format(returnDate, "PPP")}
              </span>
            )}
            {tripType === 'hourly' && (
              <span className="bg-travel-100 text-travel-800 px-2 py-1 rounded-md">
                Hourly Rental
              </span>
            )}
          </div>
        </div>
        
        {loading ? (
          <div className="flex justify-center my-12">
            <div className="animate-pulse text-center">
              <h3 className="text-xl mb-2">Finding available cabs...</h3>
              <p className="text-gray-600">This won't take long</p>
            </div>
          </div>
        ) : (
          <div className="space-y-4">
            {cabs.map((cab) => (
              <Card key={cab.id} className="overflow-hidden">
                <CardContent className="p-6">
                  <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                    <div className="md:col-span-1">
                      <div className="h-24 bg-gray-200 flex items-center justify-center mb-2">
                        <span className="text-lg font-medium">{cab.type}</span>
                      </div>
                      <p className="text-sm text-gray-500">
                        {cab.provider} • {cab.capacity} seats
                      </p>
                    </div>
                    
                    <div className="md:col-span-2">
                      <h3 className="font-medium mb-2">Features</h3>
                      <div className="flex flex-wrap gap-2">
                        {cab.features.map((feature, index) => (
                          <span key={index} className="text-xs bg-gray-100 px-2 py-1 rounded">
                            {feature}
                          </span>
                        ))}
                      </div>
                      <p className="mt-2 text-sm">
                        <span className="text-gray-600">Estimated arrival time:</span> {cab.estimatedTime}
                      </p>
                    </div>
                    
                    <div className="flex flex-col justify-center items-end">
                      <div className="text-xl font-bold text-travel-700">
                        ${cab.price}
                      </div>
                      <div className="text-xs text-gray-500 mb-3">
                        {tripType === 'oneWay' ? 'One way fare' : 'Round trip fare'}
                      </div>
                      <Button className="bg-travel-700 hover:bg-travel-800">
                        Book Now
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </div>
    </AppLayout>
  );
}
