
import React from 'react';
import AppLayout from '@/components/layout/AppLayout';
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import HotelSearchForm from '@/components/hotels/HotelSearchForm';
import { Hotel } from 'lucide-react';

export default function Hotels() {
  return (
    <AppLayout requireAuth={true}>
      <section className="relative py-12 px-4 md:px-8 overflow-hidden bg-gradient-to-br from-travel-100 via-travel-50 to-white">
        <div className="max-w-6xl mx-auto relative z-10">
          <div className="text-center mb-10">
            <h1 className="text-4xl md:text-5xl font-bold text-gray-900 mb-4">
              Find Your Perfect Stay
            </h1>
            <p className="text-xl text-gray-700 max-w-2xl mx-auto">
              Book hotels, resorts, and more at the best prices
            </p>
          </div>
          
          <div className="bg-white rounded-2xl shadow-lg overflow-hidden">
            <div className="p-1">
              <div className="flex items-center justify-center gap-2 p-4 border-b">
                <Hotel className="h-5 w-5 text-travel-700" />
                <h2 className="text-xl font-medium">Hotel Search</h2>
              </div>
              <HotelSearchForm />
            </div>
          </div>
        </div>
      </section>
      
      <section className="py-16 travel-container">
        <h2 className="text-2xl font-bold mb-8 text-center">Popular Destinations</h2>
        
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-6">
          {['New York', 'Paris', 'Tokyo', 'London'].map((city) => (
            <div key={city} className="travel-card rounded-xl overflow-hidden transition-all duration-300 hover:shadow-lg">
              <div className="h-48 bg-gray-200"></div>
              <div className="p-4">
                <h3 className="font-medium text-lg">{city}</h3>
                <p className="text-gray-600 text-sm">Explore top hotels</p>
                <div className="mt-2 text-travel-700 text-sm font-medium">
                  Starting from $89/night
                </div>
              </div>
            </div>
          ))}
        </div>
      </section>
    </AppLayout>
  );
}
