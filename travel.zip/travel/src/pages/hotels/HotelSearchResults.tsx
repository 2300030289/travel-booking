
import React, { useEffect, useState } from 'react';
import { useSearchParams } from 'react-router-dom';
import AppLayout from '@/components/layout/AppLayout';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Label } from '@/components/ui/label';
import { format } from 'date-fns';

interface Hotel {
  id: number;
  name: string;
  location: string;
  price: number;
  rating: number;
  image: string;
  amenities: string[];
}

export default function HotelSearchResults() {
  const [searchParams] = useSearchParams();
  const [hotels, setHotels] = useState<Hotel[]>([]);
  const [loading, setLoading] = useState(true);

  const location = searchParams.get('location') || '';
  const checkInDate = searchParams.get('checkIn') ? new Date(searchParams.get('checkIn')!) : new Date();
  const checkOutDate = searchParams.get('checkOut') ? new Date(searchParams.get('checkOut')!) : new Date();
  const rooms = parseInt(searchParams.get('rooms') || '1');
  const guests = parseInt(searchParams.get('guests') || '2');

  useEffect(() => {
    // Simulate API call with timeout
    setTimeout(() => {
      const mockHotels: Hotel[] = [
        {
          id: 1,
          name: "Grand Plaza Hotel",
          location: location,
          price: 150 * rooms,
          rating: 4.5,
          image: "https://placehold.co/600x400",
          amenities: ["Wi-Fi", "Swimming Pool", "Restaurant", "Gym"]
        },
        {
          id: 2,
          name: "City View Inn",
          location: location,
          price: 120 * rooms,
          rating: 4.2,
          image: "https://placehold.co/600x400",
          amenities: ["Wi-Fi", "Restaurant", "Parking", "Air Conditioning"]
        },
        {
          id: 3,
          name: "Sunset Resort",
          location: location,
          price: 200 * rooms,
          rating: 4.7,
          image: "https://placehold.co/600x400",
          amenities: ["Wi-Fi", "Swimming Pool", "Restaurant", "Spa", "Beach Access"]
        },
        {
          id: 4,
          name: "Business Hotel",
          location: location,
          price: 130 * rooms,
          rating: 4.0,
          image: "https://placehold.co/600x400",
          amenities: ["Wi-Fi", "Business Center", "Restaurant", "Laundry"]
        }
      ];
      setHotels(mockHotels);
      setLoading(false);
    }, 1000);
  }, [location, rooms]);

  const calculateNights = () => {
    const timeDiff = checkOutDate.getTime() - checkInDate.getTime();
    return Math.ceil(timeDiff / (1000 * 3600 * 24));
  };

  return (
    <AppLayout requireAuth={true}>
      <div className="py-8 travel-container">
        <h1 className="text-2xl font-bold mb-4">Hotels in {location}</h1>
        <div className="mb-6">
          <div className="flex flex-wrap gap-2 text-sm">
            <span className="bg-travel-100 text-travel-800 px-2 py-1 rounded-md">
              Check-in: {format(checkInDate, "PPP")}
            </span>
            <span className="bg-travel-100 text-travel-800 px-2 py-1 rounded-md">
              Check-out: {format(checkOutDate, "PPP")}
            </span>
            <span className="bg-travel-100 text-travel-800 px-2 py-1 rounded-md">
              {calculateNights()} nights
            </span>
            <span className="bg-travel-100 text-travel-800 px-2 py-1 rounded-md">
              {rooms} {rooms === 1 ? 'room' : 'rooms'}
            </span>
            <span className="bg-travel-100 text-travel-800 px-2 py-1 rounded-md">
              {guests} {guests === 1 ? 'guest' : 'guests'}
            </span>
          </div>
        </div>
        
        {loading ? (
          <div className="flex justify-center my-12">
            <div className="animate-pulse text-center">
              <h3 className="text-xl mb-2">Finding the best hotels for you...</h3>
              <p className="text-gray-600">This won't take long</p>
            </div>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {hotels.map((hotel) => (
              <Card key={hotel.id} className="overflow-hidden transition-all duration-300 hover:shadow-lg">
                <div className="h-48 bg-gray-200 relative">
                  <div className="absolute top-0 right-0 bg-white px-2 py-1 m-2 rounded text-sm font-medium">
                    {hotel.rating}/5 ⭐
                  </div>
                </div>
                <CardHeader>
                  <CardTitle>{hotel.name}</CardTitle>
                  <CardDescription>{hotel.location}</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="mb-4">
                    <div className="flex flex-wrap gap-1 mb-2">
                      {hotel.amenities.map((amenity, index) => (
                        <span key={index} className="text-xs bg-gray-100 px-2 py-1 rounded">
                          {amenity}
                        </span>
                      ))}
                    </div>
                  </div>
                  <div className="text-xl font-bold text-travel-700">
                    ${hotel.price} <span className="text-sm font-normal text-gray-600">per night</span>
                  </div>
                  <div className="text-sm text-gray-500">
                    Total: ${hotel.price * calculateNights()} for {calculateNights()} nights
                  </div>
                </CardContent>
                <CardFooter>
                  <Button className="w-full bg-travel-700 hover:bg-travel-800">
                    Book Now
                  </Button>
                </CardFooter>
              </Card>
            ))}
          </div>
        )}
      </div>
    </AppLayout>
  );
}
