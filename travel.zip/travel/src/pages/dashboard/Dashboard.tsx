
import React from 'react';
import AppLayout from '@/components/layout/AppLayout';
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import FlightSearchForm from '@/components/flights/FlightSearchForm';
import HotelSearchForm from '@/components/hotels/HotelSearchForm';
import TrainSearchForm from '@/components/trains/TrainSearchForm';
import BusSearchForm from '@/components/buses/BusSearchForm';
import CabSearchForm from '@/components/cabs/CabSearchForm';
import { useToast } from '@/hooks/use-toast';
import { Button } from '@/components/ui/button';
import { 
  Card, 
  CardHeader, 
  CardTitle, 
  CardDescription, 
  CardContent 
} from '@/components/ui/card';
import { CalendarDays, CreditCard, MapPin, Ticket, TrendingUp, Users } from 'lucide-react';

export default function Dashboard() {
  const { toast } = useToast();
  
  const handleLinkClick = (service: string) => {
    toast({
      title: `${service} search`,
      description: "This feature is coming soon!",
    });
  };

  const recentBookings = [
    { id: 'BK-2023-001', type: 'Flight', from: 'New York', to: 'London', date: 'May 15, 2023', status: 'Confirmed' },
    { id: 'BK-2023-002', type: 'Hotel', location: 'Paris', date: 'Jun 20-25, 2023', status: 'Completed' },
    { id: 'BK-2023-003', type: 'Bus', from: 'Chicago', to: 'Detroit', date: 'Apr 10, 2023', status: 'Cancelled' }
  ];

  return (
    <AppLayout requireAuth={true}>
      <section className="relative py-6 px-4 md:px-8 overflow-hidden bg-gradient-to-br from-travel-100 via-travel-50 to-white">
        <div className="max-w-7xl mx-auto">
          <div className="mb-8">
            <h1 className="text-3xl md:text-4xl font-bold text-gray-900 mb-2">
              Welcome to Your TripEase Dashboard
            </h1>
            <p className="text-lg text-gray-700">
              Plan and manage all your trips in one place
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-8">
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-lg flex items-center gap-2">
                  <CreditCard className="h-5 w-5 text-travel-700" />
                  Active Bookings
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-3xl font-bold">3</p>
                <p className="text-sm text-muted-foreground">Upcoming trips</p>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-lg flex items-center gap-2">
                  <TrendingUp className="h-5 w-5 text-travel-700" />
                  Reward Points
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-3xl font-bold">2,450</p>
                <p className="text-sm text-muted-foreground">Points earned</p>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-lg flex items-center gap-2">
                  <MapPin className="h-5 w-5 text-travel-700" />
                  Places Visited
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-3xl font-bold">12</p>
                <p className="text-sm text-muted-foreground">Destinations</p>
              </CardContent>
            </Card>
          </div>
          
          <div className="bg-white rounded-2xl shadow-lg overflow-hidden">
            <Tabs defaultValue="flights" className="w-full">
              <TabsList className="grid grid-cols-5 gap-2 w-full max-w-3xl mx-auto p-2">
                <TabsTrigger value="flights">Flights</TabsTrigger>
                <TabsTrigger value="hotels">Hotels</TabsTrigger>
                <TabsTrigger value="trains">Trains</TabsTrigger>
                <TabsTrigger value="buses">Buses</TabsTrigger>
                <TabsTrigger value="cabs">Cabs</TabsTrigger>
              </TabsList>
              
              <div>
                <TabsContent value="flights">
                  <FlightSearchForm />
                </TabsContent>
                
                <TabsContent value="hotels">
                  <HotelSearchForm />
                </TabsContent>
                
                <TabsContent value="trains">
                  <TrainSearchForm />
                </TabsContent>
                
                <TabsContent value="buses">
                  <BusSearchForm />
                </TabsContent>
                
                <TabsContent value="cabs">
                  <CabSearchForm />
                </TabsContent>
              </div>
            </Tabs>
          </div>
        </div>
      </section>
      
      <section className="py-10 travel-container">
        <h2 className="text-2xl font-bold mb-6">Recent Bookings</h2>
        
        <div className="bg-white rounded-lg border overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-gray-50 text-sm font-medium text-gray-600">
                <tr>
                  <th className="py-3 px-4 text-left">Booking ID</th>
                  <th className="py-3 px-4 text-left">Type</th>
                  <th className="py-3 px-4 text-left">Itinerary</th>
                  <th className="py-3 px-4 text-left">Date</th>
                  <th className="py-3 px-4 text-left">Status</th>
                  <th className="py-3 px-4 text-left">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y text-sm text-gray-700">
                {recentBookings.map((booking) => (
                  <tr key={booking.id}>
                    <td className="py-3 px-4">{booking.id}</td>
                    <td className="py-3 px-4">
                      <div className="flex items-center gap-1">
                        <Ticket className="h-4 w-4 text-travel-700" />
                        {booking.type}
                      </div>
                    </td>
                    <td className="py-3 px-4">
                      {booking.from && booking.to ? (
                        <span>{booking.from} → {booking.to}</span>
                      ) : (
                        <span>{booking.location}</span>
                      )}
                    </td>
                    <td className="py-3 px-4">{booking.date}</td>
                    <td className="py-3 px-4">
                      <span
                        className={`inline-block px-2 py-1 rounded-full text-xs font-medium ${
                          booking.status === 'Confirmed'
                            ? 'bg-green-100 text-green-800'
                            : booking.status === 'Cancelled'
                            ? 'bg-red-100 text-red-800'
                            : 'bg-blue-100 text-blue-800'
                        }`}
                      >
                        {booking.status}
                      </span>
                    </td>
                    <td className="py-3 px-4">
                      <Button 
                        variant="ghost" 
                        size="sm" 
                        onClick={() => handleLinkClick('View details')}
                      >
                        View
                      </Button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          <div className="bg-gray-50 py-3 px-4 text-right">
            <Button 
              variant="outline" 
              size="sm"
              onClick={() => handleLinkClick('View all bookings')}
            >
              View all bookings
            </Button>
          </div>
        </div>
      </section>

      <section className="py-8 bg-gray-50 travel-container">
        <h2 className="text-2xl font-bold mb-6">Recommended for you</h2>
        
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {['New York', 'Paris', 'Tokyo', 'London'].map((city) => (
            <Card key={city} className="hover-scale">
              <div className="h-48 bg-gray-200"></div>
              <CardContent className="pt-4">
                <h3 className="font-medium text-lg">{city}</h3>
                <p className="text-gray-600 text-sm">Explore amazing deals</p>
                <Button 
                  variant="link" 
                  className="p-0 mt-2 text-travel-700"
                  onClick={() => handleLinkClick(`${city} flights`)}
                >
                  View flights
                </Button>
              </CardContent>
            </Card>
          ))}
        </div>
      </section>
    </AppLayout>
  );
}
