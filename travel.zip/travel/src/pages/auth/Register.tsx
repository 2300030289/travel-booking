
import React from 'react';
import AuthForm from '@/components/auth/AuthForm';
import AppLayout from '@/components/layout/AppLayout';

export default function Register() {
  return (
    <AppLayout>
      <section className="py-12 travel-container max-w-md">
        <AuthForm isLogin={false} />
      </section>
    </AppLayout>
  );
}
