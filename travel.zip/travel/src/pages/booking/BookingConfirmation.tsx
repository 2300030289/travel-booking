
import React from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import AppLayout from '@/components/layout/AppLayout';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { format } from 'date-fns';
import { Separator } from '@/components/ui/separator';

export default function BookingConfirmation() {
  const navigate = useNavigate();
  const location = useLocation();
  const bookingData = location.state;
  
  // Generate a random booking reference
  const bookingReference = React.useMemo(() => {
    const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
    let result = '';
    for (let i = 0; i < 6; i++) {
      result += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    return result;
  }, []);
  
  // Navigate to dashboard if no booking data
  React.useEffect(() => {
    if (!bookingData?.flight) {
      navigate('/dashboard');
    }
  }, [bookingData, navigate]);
  
  if (!bookingData?.flight) {
    return null;
  }
  
  const { flight, departureDate, returnDate, passengers, totalAmount } = bookingData;
  
  return (
    <AppLayout>
      <div className="travel-container py-12">
        <div className="max-w-3xl mx-auto">
          <div className="text-center mb-8">
            <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8 text-green-600" viewBox="0 0 20 20" fill="currentColor">
                <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
              </svg>
            </div>
            <h1 className="text-3xl font-bold text-green-600 mb-2">Booking Confirmed!</h1>
            <p className="text-lg text-gray-600">
              Thank you for your booking. Your confirmation is below.
            </p>
            <p className="text-sm text-gray-600 mt-2">
              A confirmation has been sent to your email.
            </p>
          </div>
          
          <Card>
            <CardHeader className="bg-travel-50">
              <div className="flex justify-between items-center">
                <CardTitle>Booking Details</CardTitle>
                <span className="text-sm font-mono bg-gray-100 px-3 py-1 rounded-full">
                  {bookingReference}
                </span>
              </div>
            </CardHeader>
            <CardContent className="p-6">
              <div className="space-y-6">
                <div>
                  <h3 className="font-medium text-lg mb-4">Flight Information</h3>
                  <div className="bg-gray-50 rounded-lg p-4">
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
                      <div>
                        <p className="text-xl font-bold">{flight.departureTime}</p>
                        <p className="font-medium">{flight.origin}</p>
                        <p className="text-sm text-gray-600">{format(new Date(departureDate), 'EEE, MMM d, yyyy')}</p>
                      </div>
                      <div className="flex flex-col items-center">
                        <p className="text-sm text-gray-600">{flight.duration}</p>
                        <div className="relative w-full flex items-center my-2">
                          <Separator className="w-full" />
                          <div className="absolute w-2 h-2 rounded-full bg-travel-700"></div>
                        </div>
                        <p className="text-sm text-gray-600">{flight.airline} • {flight.flightNumber}</p>
                      </div>
                      <div className="text-right">
                        <p className="text-xl font-bold">{flight.arrivalTime}</p>
                        <p className="font-medium">{flight.destination}</p>
                        <p className="text-sm text-gray-600">{format(new Date(departureDate), 'EEE, MMM d, yyyy')}</p>
                      </div>
                    </div>
                    
                    <div className="flex justify-between">
                      <p className="text-sm text-gray-600">Cabin: {flight.cabin}</p>
                      <p className="text-sm text-gray-600">
                        {passengers} {passengers === 1 ? 'passenger' : 'passengers'}
                      </p>
                    </div>
                  </div>
                </div>
                
                <div>
                  <h3 className="font-medium text-lg mb-4">Payment Information</h3>
                  <div className="bg-gray-50 rounded-lg p-4">
                    <div className="flex justify-between mb-2">
                      <span>Total Amount</span>
                      <span className="font-bold">${totalAmount}</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Payment Method</span>
                      <span>Credit Card</span>
                    </div>
                  </div>
                </div>
                
                <div>
                  <h3 className="font-medium text-lg mb-4">Travel Policy</h3>
                  <ul className="space-y-2 text-sm">
                    <li className="flex items-start">
                      <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-2 text-travel-700 flex-shrink-0" viewBox="0 0 20 20" fill="currentColor">
                        <path fillRule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7-4a1 1 0 11-2 0 1 1 0 012 0zM9 9a1 1 0 000 2v3a1 1 0 001 1h1a1 1 0 100-2v-3a1 1 0 00-1-1H9z" clipRule="evenodd" />
                      </svg>
                      <span>Please arrive at the airport at least 2 hours before your departure time.</span>
                    </li>
                    <li className="flex items-start">
                      <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-2 text-travel-700 flex-shrink-0" viewBox="0 0 20 20" fill="currentColor">
                        <path fillRule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7-4a1 1 0 11-2 0 1 1 0 012 0zM9 9a1 1 0 000 2v3a1 1 0 001 1h1a1 1 0 100-2v-3a1 1 0 00-1-1H9z" clipRule="evenodd" />
                      </svg>
                      <span>
                        {flight.refundable 
                          ? 'This ticket is refundable. Cancellations must be made at least 24 hours before departure.' 
                          : 'This ticket is non-refundable. Changes may be subject to fees.'}
                      </span>
                    </li>
                    <li className="flex items-start">
                      <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-2 text-travel-700 flex-shrink-0" viewBox="0 0 20 20" fill="currentColor">
                        <path fillRule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7-4a1 1 0 11-2 0 1 1 0 012 0zM9 9a1 1 0 000 2v3a1 1 0 001 1h1a1 1 0 100-2v-3a1 1 0 00-1-1H9z" clipRule="evenodd" />
                      </svg>
                      <span>Your baggage allowance: {flight.baggage}</span>
                    </li>
                  </ul>
                </div>
              </div>
            </CardContent>
          </Card>
          
          <div className="flex flex-col sm:flex-row gap-4 justify-center mt-8">
            <Button 
              variant="outline"
              onClick={() => navigate('/bookings')}
            >
              View My Bookings
            </Button>
            <Button 
              className="bg-travel-700 hover:bg-travel-800"
              onClick={() => navigate('/dashboard')}
            >
              Back to Home
            </Button>
          </div>
        </div>
      </div>
    </AppLayout>
  );
}
