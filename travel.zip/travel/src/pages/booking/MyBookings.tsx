
import React from 'react';
import { useNavigate } from 'react-router-dom';
import AppLayout from '@/components/layout/AppLayout';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

// In a real application, this would be fetched from an API
const MOCK_BOOKINGS = [
  {
    id: 'bk-1001',
    type: 'flight',
    reference: 'ABC123',
    status: 'Confirmed',
    details: {
      airline: 'JetSpeed Airways',
      flightNumber: 'JS-1234',
      origin: 'New York (JFK)',
      destination: 'London (LHR)',
      departureDate: '2025-05-20',
      departureTime: '08:00',
      arrivalTime: '20:00'
    }
  },
  {
    id: 'bk-1002',
    type: 'flight',
    reference: 'DEF456',
    status: 'Completed',
    details: {
      airline: 'TransAtlantic',
      flightNumber: 'TA-5678',
      origin: 'London (LHR)',
      destination: 'Paris (CDG)',
      departureDate: '2025-05-01',
      departureTime: '12:30',
      arrivalTime: '14:00'
    }
  }
];

export default function MyBookings() {
  const navigate = useNavigate();
  
  return (
    <AppLayout requireAuth={true}>
      <div className="bg-travel-50 py-4">
        <div className="travel-container">
          <h1 className="text-xl font-bold">My Bookings</h1>
        </div>
      </div>
      
      <div className="travel-container py-8">
        <Tabs defaultValue="upcoming" className="w-full">
          <TabsList className="grid grid-cols-2 max-w-xs mb-6">
            <TabsTrigger value="upcoming">Upcoming</TabsTrigger>
            <TabsTrigger value="completed">Completed</TabsTrigger>
          </TabsList>
          
          <TabsContent value="upcoming">
            {MOCK_BOOKINGS.filter(b => b.status === 'Confirmed').length === 0 ? (
              <div className="text-center py-12">
                <h2 className="text-xl font-medium mb-2">No upcoming bookings</h2>
                <p className="text-gray-600 mb-6">You don't have any upcoming trips at the moment.</p>
                <Button 
                  onClick={() => navigate('/dashboard')}
                  className="bg-travel-700 hover:bg-travel-800"
                >
                  Book a Trip
                </Button>
              </div>
            ) : (
              <div className="space-y-6">
                {MOCK_BOOKINGS.filter(b => b.status === 'Confirmed').map((booking) => (
                  <Card key={booking.id}>
                    <CardHeader className="pb-2">
                      <div className="flex justify-between items-center">
                        <CardTitle className="text-lg">
                          {booking.details.origin} to {booking.details.destination}
                        </CardTitle>
                        <div className="flex gap-2 items-center">
                          <span className="text-sm bg-green-100 text-green-800 px-2 py-1 rounded-full">
                            {booking.status}
                          </span>
                          <span className="text-sm font-mono bg-gray-100 px-2 py-1 rounded-full">
                            {booking.reference}
                          </span>
                        </div>
                      </div>
                    </CardHeader>
                    <CardContent>
                      <div>
                        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-4">
                          <div>
                            <p className="text-sm text-gray-600">Airline</p>
                            <p className="font-medium">{booking.details.airline}</p>
                          </div>
                          <div>
                            <p className="text-sm text-gray-600">Date</p>
                            <p className="font-medium">
                              {new Date(booking.details.departureDate).toLocaleDateString('en-US', {
                                month: 'short',
                                day: 'numeric',
                                year: 'numeric'
                              })}
                            </p>
                          </div>
                          <div>
                            <p className="text-sm text-gray-600">Flight</p>
                            <p className="font-medium">{booking.details.flightNumber}</p>
                          </div>
                        </div>
                        
                        <div className="grid grid-cols-2 gap-4">
                          <div>
                            <p className="text-sm text-gray-600">Departure</p>
                            <p className="font-medium">{booking.details.departureTime}</p>
                          </div>
                          <div>
                            <p className="text-sm text-gray-600">Arrival</p>
                            <p className="font-medium">{booking.details.arrivalTime}</p>
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            )}
          </TabsContent>
          
          <TabsContent value="completed">
            {MOCK_BOOKINGS.filter(b => b.status === 'Completed').length === 0 ? (
              <div className="text-center py-12">
                <h2 className="text-xl font-medium mb-2">No completed bookings</h2>
                <p className="text-gray-600">You don't have any past trips.</p>
              </div>
            ) : (
              <div className="space-y-6">
                {MOCK_BOOKINGS.filter(b => b.status === 'Completed').map((booking) => (
                  <Card key={booking.id}>
                    <CardHeader className="pb-2">
                      <div className="flex justify-between items-center">
                        <CardTitle className="text-lg">
                          {booking.details.origin} to {booking.details.destination}
                        </CardTitle>
                        <div className="flex gap-2 items-center">
                          <span className="text-sm bg-gray-100 text-gray-800 px-2 py-1 rounded-full">
                            {booking.status}
                          </span>
                          <span className="text-sm font-mono bg-gray-100 px-2 py-1 rounded-full">
                            {booking.reference}
                          </span>
                        </div>
                      </div>
                    </CardHeader>
                    <CardContent>
                      <div>
                        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-4">
                          <div>
                            <p className="text-sm text-gray-600">Airline</p>
                            <p className="font-medium">{booking.details.airline}</p>
                          </div>
                          <div>
                            <p className="text-sm text-gray-600">Date</p>
                            <p className="font-medium">
                              {new Date(booking.details.departureDate).toLocaleDateString('en-US', {
                                month: 'short',
                                day: 'numeric',
                                year: 'numeric'
                              })}
                            </p>
                          </div>
                          <div>
                            <p className="text-sm text-gray-600">Flight</p>
                            <p className="font-medium">{booking.details.flightNumber}</p>
                          </div>
                        </div>
                        
                        <div className="grid grid-cols-2 gap-4">
                          <div>
                            <p className="text-sm text-gray-600">Departure</p>
                            <p className="font-medium">{booking.details.departureTime}</p>
                          </div>
                          <div>
                            <p className="text-sm text-gray-600">Arrival</p>
                            <p className="font-medium">{booking.details.arrivalTime}</p>
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            )}
          </TabsContent>
        </Tabs>
      </div>
    </AppLayout>
  );
}
