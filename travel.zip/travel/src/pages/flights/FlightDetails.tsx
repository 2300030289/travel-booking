
import React, { useState } from 'react';
import { useParams, useNavigate, useLocation } from 'react-router-dom';
import AppLayout from '@/components/layout/AppLayout';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Separator } from '@/components/ui/separator';
import { Badge } from '@/components/ui/badge';
import { useToast } from '@/components/ui/use-toast';
import { format } from 'date-fns';

// Mock flight data (same as in search results)
const MOCK_FLIGHTS = [
  {
    id: 'fl-1001',
    airline: 'JetSpeed Airways',
    flightNumber: 'JS-1234',
    origin: 'New York (JFK)',
    originFull: 'John F. Kennedy International Airport',
    destination: 'London (LHR)',
    destinationFull: 'London Heathrow Airport',
    departureTime: '08:00',
    arrivalTime: '20:00',
    duration: '8h 00m',
    price: 450,
    stops: 0,
    aircraft: 'Airbus A380',
    cabin: 'Economy',
    baggage: '1 x 23kg checked, 1 x 7kg cabin',
    amenities: ['In-flight entertainment', 'Power outlets', 'Wi-Fi (paid)'],
    refundable: false
  },
  {
    id: 'fl-1002',
    airline: 'TransAtlantic',
    flightNumber: 'TA-5678',
    origin: 'New York (JFK)',
    originFull: 'John F. Kennedy International Airport',
    destination: 'London (LHR)',
    destinationFull: 'London Heathrow Airport',
    departureTime: '12:30',
    arrivalTime: '00:30',
    duration: '8h 00m',
    price: 380,
    stops: 1,
    stopLocations: ['Dublin (DUB)'],
    stopDurations: ['1h 30m'],
    aircraft: 'Boeing 787',
    cabin: 'Economy',
    baggage: '1 x 23kg checked, 1 x 7kg cabin',
    amenities: ['In-flight entertainment', 'Power outlets', 'Wi-Fi (paid)', 'Complimentary meal'],
    refundable: false
  },
  {
    id: 'fl-1003',
    airline: 'Global Airlines',
    flightNumber: 'GA-9012',
    origin: 'New York (JFK)',
    originFull: 'John F. Kennedy International Airport',
    destination: 'London (LHR)',
    destinationFull: 'London Heathrow Airport',
    departureTime: '16:45',
    arrivalTime: '04:45',
    duration: '8h 00m',
    price: 520,
    stops: 0,
    aircraft: 'Boeing 777',
    cabin: 'Economy',
    baggage: '2 x 23kg checked, 1 x 7kg cabin',
    amenities: ['In-flight entertainment', 'Power outlets', 'Wi-Fi (included)', 'Premium meal', 'Priority boarding'],
    refundable: true
  },
  {
    id: 'fl-1004',
    airline: 'Atlantic Wings',
    flightNumber: 'AW-3456',
    origin: 'New York (JFK)',
    originFull: 'John F. Kennedy International Airport',
    destination: 'London (LHR)',
    destinationFull: 'London Heathrow Airport',
    departureTime: '22:15',
    arrivalTime: '10:15',
    duration: '8h 00m',
    price: 410,
    stops: 1,
    stopLocations: ['Reykjavik (KEF)'],
    stopDurations: ['1h 00m'],
    aircraft: 'Airbus A330',
    cabin: 'Economy',
    baggage: '1 x 23kg checked, 1 x 7kg cabin',
    amenities: ['In-flight entertainment', 'Power outlets', 'Complimentary meal'],
    refundable: false
  },
];

export default function FlightDetails() {
  const { flightId } = useParams<{ flightId: string }>();
  const location = useLocation();
  const navigate = useNavigate();
  const { toast } = useToast();
  
  const query = new URLSearchParams(location.search);
  const departureDate = query.get('departureDate') ? new Date(query.get('departureDate')!) : new Date();
  const tripType = query.get('tripType') || 'roundTrip';
  const returnDate = query.get('returnDate') ? new Date(query.get('returnDate')!) : undefined;
  const passengers = parseInt(query.get('passengers') || '1');
  
  const flight = MOCK_FLIGHTS.find(f => f.id === flightId);
  const [selectedSeats, setSelectedSeats] = useState<string[]>([]);
  const [showPaymentForm, setShowPaymentForm] = useState(false);
  
  const [formData, setFormData] = useState({
    firstName: '',
    lastName: '',
    email: '',
    phone: '',
    cardNumber: '',
    cardExpiry: '',
    cardCvv: ''
  });
  
  if (!flight) {
    return (
      <AppLayout>
        <div className="travel-container py-12 text-center">
          <h1 className="text-2xl font-bold mb-4">Flight Not Found</h1>
          <p>Sorry, we couldn't find details for this flight.</p>
          <Button 
            onClick={() => navigate(-1)}
            className="mt-4 bg-travel-700 hover:bg-travel-800"
          >
            Go Back
          </Button>
        </div>
      </AppLayout>
    );
  }
  
  const totalPrice = flight.price * passengers;
  const taxes = Math.round(totalPrice * 0.12);
  const grandTotal = totalPrice + taxes;
  
  const handleContinue = () => {
    setShowPaymentForm(true);
  };
  
  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };
  
  const handlePayment = (e: React.FormEvent) => {
    e.preventDefault();
    
    // Validate form (simplified)
    const requiredFields = ['firstName', 'lastName', 'email', 'cardNumber', 'cardExpiry', 'cardCvv'];
    const hasEmptyFields = requiredFields.some(field => !formData[field as keyof typeof formData]);
    
    if (hasEmptyFields) {
      toast({
        title: "Incomplete information",
        description: "Please fill in all required fields",
        variant: "destructive",
      });
      return;
    }
    
    // Mock successful payment
    toast({
      title: "Processing payment...",
    });
    
    // Simulate API call with timeout
    setTimeout(() => {
      navigate('/booking-confirmation', { 
        state: { 
          flight, 
          departureDate, 
          returnDate, 
          passengers,
          totalAmount: grandTotal
        } 
      });
    }, 1500);
  };

  return (
    <AppLayout>
      <div className="bg-travel-50 py-4">
        <div className="travel-container">
          <div className="flex justify-between items-center">
            <div>
              <h1 className="text-xl font-bold">Flight Details</h1>
              <p className="text-sm text-gray-600">
                {flight.origin} to {flight.destination} • {format(departureDate, 'EEEE, MMMM d, yyyy')}
              </p>
            </div>
            <Button 
              variant="outline" 
              onClick={() => navigate(-1)}
            >
              Back to Search
            </Button>
          </div>
        </div>
      </div>
      
      <div className="travel-container py-8">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Flight details */}
          <div className="lg:col-span-2 space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>{flight.airline}</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
                  <div>
                    <p className="text-2xl font-bold">{flight.departureTime}</p>
                    <p className="font-medium">{flight.origin}</p>
                    <p className="text-sm text-gray-600">{flight.originFull}</p>
                    <p className="text-sm text-gray-600">{format(departureDate, 'EEE, MMM d, yyyy')}</p>
                  </div>
                  
                  <div className="flex flex-col items-center">
                    <Badge className="mb-2" variant={flight.stops === 0 ? "secondary" : "outline"}>
                      {flight.stops === 0 ? 'Non-stop' : `${flight.stops} stop`}
                    </Badge>
                    <p className="text-sm text-gray-600">{flight.duration}</p>
                    <div className="relative w-full flex items-center my-2">
                      <Separator className="w-full" />
                      <div className="absolute w-2 h-2 rounded-full bg-travel-700"></div>
                    </div>
                    <p className="text-sm text-gray-600">{flight.flightNumber}</p>
                  </div>
                  
                  <div className="text-right">
                    <p className="text-2xl font-bold">{flight.arrivalTime}</p>
                    <p className="font-medium">{flight.destination}</p>
                    <p className="text-sm text-gray-600">{flight.destinationFull}</p>
                    <p className="text-sm text-gray-600">{format(departureDate, 'EEE, MMM d, yyyy')}</p>
                  </div>
                </div>
                
                {flight.stops > 0 && (
                  <div className="bg-gray-50 p-4 rounded-lg mb-6">
                    <h3 className="font-medium mb-2">Connection Details</h3>
                    <p>
                      {flight.stopDurations?.[0]} layover in {flight.stopLocations?.[0]}
                    </p>
                  </div>
                )}
                
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div>
                    <h3 className="font-medium mb-1">Cabin</h3>
                    <p>{flight.cabin}</p>
                  </div>
                  <div>
                    <h3 className="font-medium mb-1">Aircraft</h3>
                    <p>{flight.aircraft}</p>
                  </div>
                  <div>
                    <h3 className="font-medium mb-1">Baggage Allowance</h3>
                    <p>{flight.baggage}</p>
                  </div>
                </div>
                
                <div className="mt-4">
                  <h3 className="font-medium mb-1">Amenities</h3>
                  <ul className="grid grid-cols-2 gap-2">
                    {flight.amenities.map((amenity, index) => (
                      <li key={index} className="flex items-center">
                        <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 mr-2 text-green-500" viewBox="0 0 20 20" fill="currentColor">
                          <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                        </svg>
                        {amenity}
                      </li>
                    ))}
                  </ul>
                </div>
              </CardContent>
            </Card>
            
            {!showPaymentForm ? (
              <Card>
                <CardHeader>
                  <CardTitle>Passenger Information</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="mb-4">
                    You're booking for {passengers} {passengers === 1 ? 'passenger' : 'passengers'}
                  </p>
                  
                  <Button 
                    onClick={handleContinue}
                    className="w-full bg-travel-700 hover:bg-travel-800"
                  >
                    Continue to Payment
                  </Button>
                </CardContent>
              </Card>
            ) : (
              <Card>
                <CardHeader>
                  <CardTitle>Payment Information</CardTitle>
                </CardHeader>
                <CardContent>
                  <form onSubmit={handlePayment} className="space-y-4">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div>
                        <label htmlFor="firstName" className="block text-sm font-medium mb-1">First Name</label>
                        <input
                          type="text"
                          id="firstName"
                          name="firstName"
                          value={formData.firstName}
                          onChange={handleInputChange}
                          className="w-full p-2 border border-gray-300 rounded-md"
                          required
                        />
                      </div>
                      <div>
                        <label htmlFor="lastName" className="block text-sm font-medium mb-1">Last Name</label>
                        <input
                          type="text"
                          id="lastName"
                          name="lastName"
                          value={formData.lastName}
                          onChange={handleInputChange}
                          className="w-full p-2 border border-gray-300 rounded-md"
                          required
                        />
                      </div>
                    </div>
                    
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div>
                        <label htmlFor="email" className="block text-sm font-medium mb-1">Email</label>
                        <input
                          type="email"
                          id="email"
                          name="email"
                          value={formData.email}
                          onChange={handleInputChange}
                          className="w-full p-2 border border-gray-300 rounded-md"
                          required
                        />
                      </div>
                      <div>
                        <label htmlFor="phone" className="block text-sm font-medium mb-1">Phone Number</label>
                        <input
                          type="tel"
                          id="phone"
                          name="phone"
                          value={formData.phone}
                          onChange={handleInputChange}
                          className="w-full p-2 border border-gray-300 rounded-md"
                        />
                      </div>
                    </div>
                    
                    <div className="mt-8 mb-4">
                      <h3 className="font-medium text-lg mb-4">Payment Details</h3>
                      
                      <div className="space-y-4">
                        <div>
                          <label htmlFor="cardNumber" className="block text-sm font-medium mb-1">Card Number</label>
                          <input
                            type="text"
                            id="cardNumber"
                            name="cardNumber"
                            value={formData.cardNumber}
                            onChange={handleInputChange}
                            placeholder="1234 5678 9012 3456"
                            className="w-full p-2 border border-gray-300 rounded-md"
                            required
                          />
                        </div>
                        
                        <div className="grid grid-cols-2 gap-4">
                          <div>
                            <label htmlFor="cardExpiry" className="block text-sm font-medium mb-1">Expiry Date</label>
                            <input
                              type="text"
                              id="cardExpiry"
                              name="cardExpiry"
                              value={formData.cardExpiry}
                              onChange={handleInputChange}
                              placeholder="MM/YY"
                              className="w-full p-2 border border-gray-300 rounded-md"
                              required
                            />
                          </div>
                          <div>
                            <label htmlFor="cardCvv" className="block text-sm font-medium mb-1">CVV</label>
                            <input
                              type="text"
                              id="cardCvv"
                              name="cardCvv"
                              value={formData.cardCvv}
                              onChange={handleInputChange}
                              placeholder="123"
                              className="w-full p-2 border border-gray-300 rounded-md"
                              required
                            />
                          </div>
                        </div>
                      </div>
                    </div>
                    
                    <div className="pt-4">
                      <Button 
                        type="submit"
                        className="w-full bg-travel-700 hover:bg-travel-800"
                      >
                        Pay ${grandTotal}
                      </Button>
                    </div>
                  </form>
                </CardContent>
              </Card>
            )}
          </div>
          
          {/* Price summary */}
          <div>
            <Card>
              <CardHeader>
                <CardTitle>Price Summary</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex justify-between">
                    <span>Base Fare ({passengers} {passengers === 1 ? 'passenger' : 'passengers'})</span>
                    <span>${totalPrice}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Taxes & Fees</span>
                    <span>${taxes}</span>
                  </div>
                  <Separator />
                  <div className="flex justify-between font-bold">
                    <span>Total</span>
                    <span>${grandTotal}</span>
                  </div>
                  
                  <div className="text-sm mt-6">
                    <p className={flight.refundable ? 'text-green-600' : 'text-amber-600'}>
                      {flight.refundable ? '✓ Refundable' : '✗ Non-refundable'}
                    </p>
                    <p className="mt-2 text-gray-600">
                      By proceeding with payment, you agree to our terms and conditions and privacy policy.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </AppLayout>
  );
}
