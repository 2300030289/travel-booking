
import React, { useEffect, useState } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import AppLayout from '@/components/layout/AppLayout';
import { Button } from '@/components/ui/button';
import { Separator } from '@/components/ui/separator';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent } from '@/components/ui/card';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { Label } from '@/components/ui/label';
import { format } from 'date-fns';

// Mock flight data
const MOCK_FLIGHTS = [
  {
    id: 'fl-1001',
    airline: 'JetSpeed Airways',
    flightNumber: 'JS-1234',
    origin: 'New York (JFK)',
    destination: 'London (LHR)',
    departureTime: '08:00',
    arrivalTime: '20:00',
    duration: '8h 00m',
    price: 450,
    stops: 0,
    aircraft: 'Airbus A380'
  },
  {
    id: 'fl-1002',
    airline: 'TransAtlantic',
    flightNumber: 'TA-5678',
    origin: 'New York (JFK)',
    destination: 'London (LHR)',
    departureTime: '12:30',
    arrivalTime: '00:30',
    duration: '8h 00m',
    price: 380,
    stops: 1,
    stopLocations: ['Dublin (DUB)'],
    stopDurations: ['1h 30m'],
    aircraft: 'Boeing 787'
  },
  {
    id: 'fl-1003',
    airline: 'Global Airlines',
    flightNumber: 'GA-9012',
    origin: 'New York (JFK)',
    destination: 'London (LHR)',
    departureTime: '16:45',
    arrivalTime: '04:45',
    duration: '8h 00m',
    price: 520,
    stops: 0,
    aircraft: 'Boeing 777'
  },
  {
    id: 'fl-1004',
    airline: 'Atlantic Wings',
    flightNumber: 'AW-3456',
    origin: 'New York (JFK)',
    destination: 'London (LHR)',
    departureTime: '22:15',
    arrivalTime: '10:15',
    duration: '8h 00m',
    price: 410,
    stops: 1,
    stopLocations: ['Reykjavik (KEF)'],
    stopDurations: ['1h 00m'],
    aircraft: 'Airbus A330'
  },
];

type SortOption = 'price' | 'duration' | 'departure' | 'arrival';

export default function FlightSearchResults() {
  const location = useLocation();
  const navigate = useNavigate();
  const query = new URLSearchParams(location.search);
  
  const [flights, setFlights] = useState(MOCK_FLIGHTS);
  const [sortOption, setSortOption] = useState<SortOption>('price');
  const [filterOptions, setFilterOptions] = useState({
    nonstop: false,
    maxPrice: 1000,
  });
  
  // Get search params from URL
  const origin = query.get('origin') || '';
  const destination = query.get('destination') || '';
  const departureDate = query.get('departureDate') ? new Date(query.get('departureDate')!) : new Date();
  const tripType = query.get('tripType') || 'roundTrip';
  const returnDate = query.get('returnDate') ? new Date(query.get('returnDate')!) : undefined;
  const passengers = query.get('passengers') || '1';
  
  // Sort flights based on selected option
  useEffect(() => {
    let sortedFlights = [...MOCK_FLIGHTS];
    
    switch(sortOption) {
      case 'price':
        sortedFlights.sort((a, b) => a.price - b.price);
        break;
      case 'duration':
        // Simple sort as all flights have the same duration in our mock data
        break;
      case 'departure':
        sortedFlights.sort((a, b) => a.departureTime.localeCompare(b.departureTime));
        break;
      case 'arrival':
        sortedFlights.sort((a, b) => a.arrivalTime.localeCompare(b.arrivalTime));
        break;
    }
    
    // Apply filters
    if (filterOptions.nonstop) {
      sortedFlights = sortedFlights.filter(flight => flight.stops === 0);
    }
    
    sortedFlights = sortedFlights.filter(flight => flight.price <= filterOptions.maxPrice);
    
    setFlights(sortedFlights);
  }, [sortOption, filterOptions]);
  
  const handleSelectFlight = (flightId: string) => {
    navigate(`/flights/${flightId}?${location.search}`);
  };
  
  const handleFilterChange = (key: keyof typeof filterOptions, value: any) => {
    setFilterOptions(prev => ({
      ...prev,
      [key]: value
    }));
  };

  return (
    <AppLayout>
      <div className="bg-travel-50 py-4">
        <div className="travel-container">
          <div className="flex justify-between items-center">
            <div>
              <h1 className="text-xl font-bold">Flight Search Results</h1>
              <p className="text-sm text-gray-600">
                {origin} to {destination} • {format(departureDate, 'MMM dd')}
                {tripType === 'roundTrip' && returnDate && ` - ${format(returnDate, 'MMM dd')}`} • 
                {passengers} {parseInt(passengers) === 1 ? 'passenger' : 'passengers'}
              </p>
            </div>
            <Button 
              variant="outline" 
              onClick={() => navigate('/dashboard')}
            >
              Change Search
            </Button>
          </div>
        </div>
      </div>
      
      <div className="travel-container py-8">
        <div className="flex flex-col lg:flex-row gap-8">
          {/* Sidebar for filters */}
          <div className="lg:w-1/4">
            <div className="travel-card p-6 sticky top-6">
              <h2 className="font-semibold text-lg mb-4">Filters</h2>
              
              <div className="space-y-6">
                <div>
                  <h3 className="font-medium mb-2">Stops</h3>
                  <div className="flex items-center">
                    <input 
                      type="checkbox" 
                      id="nonstop" 
                      checked={filterOptions.nonstop}
                      onChange={(e) => handleFilterChange('nonstop', e.target.checked)}
                      className="rounded text-travel-600 focus:ring-travel-500"
                    />
                    <label htmlFor="nonstop" className="ml-2 text-sm">Non-stop only</label>
                  </div>
                </div>
                
                <div>
                  <h3 className="font-medium mb-2">Price Range</h3>
                  <input 
                    type="range" 
                    min="100" 
                    max="1000" 
                    step="50"
                    value={filterOptions.maxPrice}
                    onChange={(e) => handleFilterChange('maxPrice', Number(e.target.value))}
                    className="w-full"
                  />
                  <div className="flex justify-between text-sm text-gray-600">
                    <span>$100</span>
                    <span>${filterOptions.maxPrice}</span>
                  </div>
                </div>
                
                <div>
                  <h3 className="font-medium mb-2">Sort By</h3>
                  <RadioGroup 
                    value={sortOption} 
                    onValueChange={(value) => setSortOption(value as SortOption)}
                    className="space-y-1"
                  >
                    <div className="flex items-center space-x-2">
                      <RadioGroupItem value="price" id="price" />
                      <Label htmlFor="price">Price</Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <RadioGroupItem value="duration" id="duration" />
                      <Label htmlFor="duration">Duration</Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <RadioGroupItem value="departure" id="departure" />
                      <Label htmlFor="departure">Departure Time</Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <RadioGroupItem value="arrival" id="arrival" />
                      <Label htmlFor="arrival">Arrival Time</Label>
                    </div>
                  </RadioGroup>
                </div>
              </div>
            </div>
          </div>
          
          {/* Flight results */}
          <div className="lg:w-3/4">
            {flights.length === 0 ? (
              <div className="travel-card p-6 text-center">
                <h2 className="font-medium text-lg">No flights found</h2>
                <p className="text-gray-600">Try adjusting your filters or search criteria</p>
              </div>
            ) : (
              <div className="space-y-4">
                {flights.map((flight) => (
                  <Card key={flight.id} className="overflow-hidden">
                    <CardContent className="p-0">
                      <div className="p-6">
                        <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-4">
                          <div className="mb-2 md:mb-0">
                            <p className="font-medium">{flight.airline}</p>
                            <p className="text-sm text-gray-600">{flight.flightNumber} • {flight.aircraft}</p>
                          </div>
                          <Badge variant={flight.stops === 0 ? "secondary" : "outline"}>
                            {flight.stops === 0 ? 'Non-stop' : `${flight.stops} stop`}
                          </Badge>
                        </div>
                        
                        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                          <div>
                            <p className="text-lg font-semibold">{flight.departureTime}</p>
                            <p className="text-sm text-gray-600">{flight.origin}</p>
                          </div>
                          <div className="flex flex-col items-center">
                            <p className="text-xs text-gray-500">{flight.duration}</p>
                            <div className="relative w-full flex items-center justify-center my-2">
                              <Separator className="w-full" />
                              <div className="absolute w-2 h-2 rounded-full bg-travel-700"></div>
                            </div>
                            {flight.stops > 0 && (
                              <div className="text-xs text-gray-500">
                                via {flight.stopLocations?.[0]} ({flight.stopDurations?.[0]})
                              </div>
                            )}
                          </div>
                          <div className="text-right">
                            <p className="text-lg font-semibold">{flight.arrivalTime}</p>
                            <p className="text-sm text-gray-600">{flight.destination}</p>
                          </div>
                        </div>
                      </div>
                      
                      <div className="bg-gray-50 p-4 flex flex-col sm:flex-row justify-between items-center border-t">
                        <div className="text-center sm:text-left mb-4 sm:mb-0">
                          <p className="text-2xl font-bold text-travel-900">${flight.price}</p>
                          <p className="text-xs text-gray-600">per person</p>
                        </div>
                        <Button 
                          className="bg-travel-700 hover:bg-travel-800 w-full sm:w-auto"
                          onClick={() => handleSelectFlight(flight.id)}
                        >
                          Select Flight
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    </AppLayout>
  );
}
