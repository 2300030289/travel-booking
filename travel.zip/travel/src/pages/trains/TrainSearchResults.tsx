
import React, { useEffect, useState } from 'react';
import { useSearchParams } from 'react-router-dom';
import AppLayout from '@/components/layout/AppLayout';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardFooter } from '@/components/ui/card';
import { format } from 'date-fns';

interface Train {
  id: number;
  name: string;
  number: string;
  origin: string;
  destination: string;
  departureTime: string;
  arrivalTime: string;
  duration: string;
  price: number;
  availableSeats: number;
  classes: string[];
}

export default function TrainSearchResults() {
  const [searchParams] = useSearchParams();
  const [trains, setTrains] = useState<Train[]>([]);
  const [loading, setLoading] = useState(true);

  const origin = searchParams.get('origin') || '';
  const destination = searchParams.get('destination') || '';
  const departureDate = searchParams.get('departureDate') ? new Date(searchParams.get('departureDate')!) : new Date();
  const passengers = parseInt(searchParams.get('passengers') || '1');
  const trainClass = searchParams.get('class') || 'all';

  useEffect(() => {
    // Simulate API call with timeout
    setTimeout(() => {
      const mockTrains: Train[] = [
        {
          id: 1,
          name: "Express Rajdhani",
          number: "12301",
          origin: origin,
          destination: destination,
          departureTime: "06:00",
          arrivalTime: "12:30",
          duration: "6h 30m",
          price: 45,
          availableSeats: 42,
          classes: ["FC", "AC", "SL"]
        },
        {
          id: 2,
          name: "Shatabdi Express",
          number: "12002",
          origin: origin,
          destination: destination,
          departureTime: "08:15",
          arrivalTime: "13:45",
          duration: "5h 30m",
          price: 55,
          availableSeats: 28,
          classes: ["FC", "AC"]
        },
        {
          id: 3,
          name: "SuperFast Express",
          number: "12345",
          origin: origin,
          destination: destination,
          departureTime: "14:20",
          arrivalTime: "22:15",
          duration: "7h 55m",
          price: 38,
          availableSeats: 67,
          classes: ["SL", "AC", "TC"]
        },
        {
          id: 4,
          name: "Duronto Express",
          number: "12276",
          origin: origin,
          destination: destination,
          departureTime: "22:30",
          arrivalTime: "05:15",
          duration: "6h 45m",
          price: 42,
          availableSeats: 53,
          classes: ["FC", "AC", "SL", "TC"]
        }
      ];
      setTrains(mockTrains);
      setLoading(false);
    }, 1000);
  }, [origin, destination]);

  return (
    <AppLayout requireAuth={true}>
      <div className="py-8 travel-container">
        <h1 className="text-2xl font-bold mb-4">Trains from {origin} to {destination}</h1>
        <div className="mb-6">
          <div className="flex flex-wrap gap-2 text-sm">
            <span className="bg-travel-100 text-travel-800 px-2 py-1 rounded-md">
              Date: {format(departureDate, "PPP")}
            </span>
            <span className="bg-travel-100 text-travel-800 px-2 py-1 rounded-md">
              {passengers} {passengers === 1 ? 'passenger' : 'passengers'}
            </span>
            {trainClass !== 'all' && (
              <span className="bg-travel-100 text-travel-800 px-2 py-1 rounded-md">
                Class: {trainClass.toUpperCase()}
              </span>
            )}
          </div>
        </div>
        
        {loading ? (
          <div className="flex justify-center my-12">
            <div className="animate-pulse text-center">
              <h3 className="text-xl mb-2">Finding trains...</h3>
              <p className="text-gray-600">This won't take long</p>
            </div>
          </div>
        ) : (
          <div className="space-y-4">
            {trains.map((train) => (
              <Card key={train.id} className="overflow-hidden">
                <CardContent className="p-6">
                  <div className="grid grid-cols-1 lg:grid-cols-5 gap-4">
                    <div className="lg:col-span-2">
                      <h3 className="text-lg font-medium">{train.name}</h3>
                      <p className="text-sm text-gray-500">Train #{train.number}</p>
                      <div className="mt-2 flex flex-wrap gap-1">
                        {train.classes.map((cls, index) => (
                          <span key={index} className="text-xs bg-gray-100 px-2 py-1 rounded">
                            {cls}
                          </span>
                        ))}
                      </div>
                    </div>
                    
                    <div className="flex flex-col justify-center">
                      <div className="flex items-center gap-3">
                        <div>
                          <div className="text-lg font-medium">{train.departureTime}</div>
                          <div className="text-xs text-gray-500">{train.origin}</div>
                        </div>
                        <div className="flex-1 border-t border-dashed border-gray-300 relative">
                          <div className="absolute -top-2 left-1/2 -translate-x-1/2 bg-white px-2 text-xs text-gray-500">
                            {train.duration}
                          </div>
                        </div>
                        <div>
                          <div className="text-lg font-medium">{train.arrivalTime}</div>
                          <div className="text-xs text-gray-500">{train.destination}</div>
                        </div>
                      </div>
                    </div>
                    
                    <div className="flex flex-col justify-center items-center lg:items-start">
                      <div className="text-sm">
                        <span className="text-green-600 font-medium">{train.availableSeats} seats available</span>
                      </div>
                    </div>
                    
                    <div className="flex flex-col justify-center items-end">
                      <div className="text-xl font-bold text-travel-700">
                        ${train.price * passengers}
                      </div>
                      <div className="text-xs text-gray-500">
                        ${train.price} per passenger
                      </div>
                      <Button className="mt-2 bg-travel-700 hover:bg-travel-800">
                        Book Now
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </div>
    </AppLayout>
  );
}
