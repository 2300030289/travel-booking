
import React from 'react';
import AppLayout from '@/components/layout/AppLayout';
import TrainSearchForm from '@/components/trains/TrainSearchForm';
import { Train } from 'lucide-react';

export default function Trains() {
  return (
    <AppLayout requireAuth={true}>
      <section className="relative py-12 px-4 md:px-8 overflow-hidden bg-gradient-to-br from-travel-100 via-travel-50 to-white">
        <div className="max-w-6xl mx-auto relative z-10">
          <div className="text-center mb-10">
            <h1 className="text-4xl md:text-5xl font-bold text-gray-900 mb-4">
              Book Train Tickets
            </h1>
            <p className="text-xl text-gray-700 max-w-2xl mx-auto">
              Search and book train tickets for your journey
            </p>
          </div>
          
          <div className="bg-white rounded-2xl shadow-lg overflow-hidden">
            <div className="p-1">
              <div className="flex items-center justify-center gap-2 p-4 border-b">
                <Train className="h-5 w-5 text-travel-700" />
                <h2 className="text-xl font-medium">Train Search</h2>
              </div>
              <TrainSearchForm />
            </div>
          </div>
        </div>
      </section>
      
      <section className="py-16 travel-container">
        <h2 className="text-2xl font-bold mb-8 text-center">Popular Routes</h2>
        
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {[
            { from: 'New York', to: 'Washington DC' },
            { from: 'London', to: 'Edinburgh' },
            { from: 'Paris', to: 'Lyon' },
            { from: 'Tokyo', to: 'Kyoto' }
          ].map((route, i) => (
            <div key={i} className="travel-card rounded-xl p-6 transition-all duration-300 hover:shadow-lg">
              <div className="flex items-center gap-3 mb-4">
                <div>
                  <div className="font-medium">{route.from}</div>
                </div>
                <div className="flex-1 border-t border-dashed border-gray-300"></div>
                <div>
                  <div className="font-medium">{route.to}</div>
                </div>
              </div>
              <div className="text-sm text-gray-600 mb-2">Multiple trains daily</div>
              <div className="text-travel-700 font-medium">
                From $35
              </div>
            </div>
          ))}
        </div>
      </section>
    </AppLayout>
  );
}
