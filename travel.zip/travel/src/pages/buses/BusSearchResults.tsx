
import React, { useEffect, useState } from 'react';
import { useSearchParams } from 'react-router-dom';
import AppLayout from '@/components/layout/AppLayout';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { format } from 'date-fns';

interface Bus {
  id: number;
  company: string;
  busType: string;
  departureTime: string;
  arrivalTime: string;
  duration: string;
  origin: string;
  destination: string;
  price: number;
  availableSeats: number;
  amenities: string[];
}

export default function BusSearchResults() {
  const [searchParams] = useSearchParams();
  const [buses, setBuses] = useState<Bus[]>([]);
  const [loading, setLoading] = useState(true);

  const origin = searchParams.get('origin') || '';
  const destination = searchParams.get('destination') || '';
  const departureDate = searchParams.get('departureDate') ? new Date(searchParams.get('departureDate')!) : new Date();
  const passengers = parseInt(searchParams.get('passengers') || '1');

  useEffect(() => {
    // Simulate API call with timeout
    setTimeout(() => {
      const mockBuses: Bus[] = [
        {
          id: 1,
          company: "Express Travels",
          busType: "AC Sleeper",
          origin: origin,
          destination: destination,
          departureTime: "20:30",
          arrivalTime: "06:15",
          duration: "9h 45m",
          price: 35,
          availableSeats: 12,
          amenities: ["WiFi", "Charging Point", "Blanket"]
        },
        {
          id: 2,
          company: "Royal Coaches",
          busType: "AC Seater",
          origin: origin,
          destination: destination,
          departureTime: "09:00",
          arrivalTime: "16:30",
          duration: "7h 30m",
          price: 28,
          availableSeats: 5,
          amenities: ["WiFi", "Water Bottle", "Entertainment System"]
        },
        {
          id: 3,
          company: "Deluxe Bus Service",
          busType: "Non-AC Sleeper",
          origin: origin,
          destination: destination,
          departureTime: "21:45",
          arrivalTime: "07:00",
          duration: "9h 15m",
          price: 25,
          availableSeats: 18,
          amenities: ["Charging Point", "Blanket"]
        },
        {
          id: 4,
          company: "City Link",
          busType: "AC Semi-Sleeper",
          origin: origin,
          destination: destination,
          departureTime: "18:30",
          arrivalTime: "02:30",
          duration: "8h 00m",
          price: 32,
          availableSeats: 8,
          amenities: ["WiFi", "Snacks", "Water Bottle", "Blanket"]
        }
      ];
      setBuses(mockBuses);
      setLoading(false);
    }, 1000);
  }, [origin, destination]);

  return (
    <AppLayout requireAuth={true}>
      <div className="py-8 travel-container">
        <h1 className="text-2xl font-bold mb-4">Buses from {origin} to {destination}</h1>
        <div className="mb-6">
          <div className="flex flex-wrap gap-2 text-sm">
            <span className="bg-travel-100 text-travel-800 px-2 py-1 rounded-md">
              Date: {format(departureDate, "PPP")}
            </span>
            <span className="bg-travel-100 text-travel-800 px-2 py-1 rounded-md">
              {passengers} {passengers === 1 ? 'passenger' : 'passengers'}
            </span>
          </div>
        </div>
        
        {loading ? (
          <div className="flex justify-center my-12">
            <div className="animate-pulse text-center">
              <h3 className="text-xl mb-2">Finding buses...</h3>
              <p className="text-gray-600">This won't take long</p>
            </div>
          </div>
        ) : (
          <div className="space-y-4">
            {buses.map((bus) => (
              <Card key={bus.id} className="overflow-hidden">
                <CardContent className="p-6">
                  <div className="grid grid-cols-1 lg:grid-cols-5 gap-4">
                    <div>
                      <h3 className="text-lg font-medium">{bus.company}</h3>
                      <p className="text-sm text-gray-500">{bus.busType}</p>
                      <div className="mt-2 flex flex-wrap gap-1">
                        {bus.amenities.map((amenity, index) => (
                          <span key={index} className="text-xs bg-gray-100 px-2 py-1 rounded">
                            {amenity}
                          </span>
                        ))}
                      </div>
                    </div>
                    
                    <div className="flex flex-col justify-center lg:col-span-2">
                      <div className="flex items-center gap-3">
                        <div>
                          <div className="text-lg font-medium">{bus.departureTime}</div>
                          <div className="text-xs text-gray-500">{bus.origin}</div>
                        </div>
                        <div className="flex-1 border-t border-dashed border-gray-300 relative">
                          <div className="absolute -top-2 left-1/2 -translate-x-1/2 bg-white px-2 text-xs text-gray-500">
                            {bus.duration}
                          </div>
                        </div>
                        <div>
                          <div className="text-lg font-medium">{bus.arrivalTime}</div>
                          <div className="text-xs text-gray-500">{bus.destination}</div>
                        </div>
                      </div>
                    </div>
                    
                    <div className="flex flex-col justify-center items-center lg:items-start">
                      <div className="text-sm">
                        <span className={`font-medium ${bus.availableSeats < 10 ? 'text-red-500' : 'text-green-600'}`}>
                          {bus.availableSeats} seats left
                        </span>
                      </div>
                    </div>
                    
                    <div className="flex flex-col justify-center items-end">
                      <div className="text-xl font-bold text-travel-700">
                        ${bus.price * passengers}
                      </div>
                      <div className="text-xs text-gray-500">
                        ${bus.price} per passenger
                      </div>
                      <Button className="mt-2 bg-travel-700 hover:bg-travel-800">
                        Book Now
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </div>
    </AppLayout>
  );
}
