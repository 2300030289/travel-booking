
import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route } from "react-router-dom";

import Index from "./pages/Index";
import NotFound from "./pages/NotFound";
import Login from "./pages/auth/Login";
import Register from "./pages/auth/Register";
import Dashboard from "./pages/dashboard/Dashboard";
import FlightSearchResults from "./pages/flights/FlightSearchResults";
import FlightDetails from "./pages/flights/FlightDetails";
import BookingConfirmation from "./pages/booking/BookingConfirmation";
import MyBookings from "./pages/booking/MyBookings";
import Profile from "./pages/profile/Profile";

// New imports for hotels, trains, buses, cabs
import Hotels from "./pages/hotels/Hotels";
import HotelSearchResults from "./pages/hotels/HotelSearchResults";
import Trains from "./pages/trains/Trains";
import TrainSearchResults from "./pages/trains/TrainSearchResults";
import Buses from "./pages/buses/Buses";
import BusSearchResults from "./pages/buses/BusSearchResults";
import Cabs from "./pages/cabs/Cabs";
import CabSearchResults from "./pages/cabs/CabSearchResults";

const queryClient = new QueryClient();

const App = () => (
  <QueryClientProvider client={queryClient}>
    <TooltipProvider>
      <Toaster />
      <Sonner />
      <BrowserRouter>
        <Routes>
          <Route path="/" element={<Index />} />
          <Route path="/login" element={<Login />} />
          <Route path="/register" element={<Register />} />
          <Route path="/dashboard" element={<Dashboard />} />
          <Route path="/profile" element={<Profile />} />
          
          {/* Flight routes */}
          <Route path="/flights/search" element={<FlightSearchResults />} />
          <Route path="/flights/:flightId" element={<FlightDetails />} />
          
          {/* Hotel routes */}
          <Route path="/hotels" element={<Hotels />} />
          <Route path="/hotels/search" element={<HotelSearchResults />} />
          
          {/* Train routes */}
          <Route path="/trains" element={<Trains />} />
          <Route path="/trains/search" element={<TrainSearchResults />} />
          
          {/* Bus routes */}
          <Route path="/buses" element={<Buses />} />
          <Route path="/buses/search" element={<BusSearchResults />} />
          
          {/* Cab routes */}
          <Route path="/cabs" element={<Cabs />} />
          <Route path="/cabs/search" element={<CabSearchResults />} />
          
          {/* Booking routes */}
          <Route path="/booking-confirmation" element={<BookingConfirmation />} />
          <Route path="/bookings" element={<MyBookings />} />
          
          <Route path="*" element={<NotFound />} />
        </Routes>
      </BrowserRouter>
    </TooltipProvider>
  </QueryClientProvider>
);

export default App;
