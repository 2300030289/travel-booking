package com.klu.Registration.Service;

import com.klu.Registration.Dto.UserDto;

public interface UserService {

	String addUser(UserDto userDto);

}
