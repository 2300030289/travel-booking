package com.klu.Registration.Service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.klu.Registration.Dto.UserDto;
import com.klu.Registration.Entity.User;
import com.klu.Registration.Repo.UserRepo;
import com.klu.Registration.Service.UserService;

@Service
public class UserIMPL implements UserService {

	
	@Autowired
	private UserRepo userRepo;
	
	@Override
	public String addUser(UserDto userDto) {
		
		User user = new User(
				
				userDto.getUserid(),
				userDto.getFirstname(),
				userDto.getSecondname(),
				userDto.getUsername(),
				userDto.getEmail(),
				userDto.getPassword()
		);
		
		userRepo.save(user);
		
		return user.getUsername();
	}

}
