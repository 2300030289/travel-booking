package com.klu.Registration.UserController;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.klu.Registration.Dto.UserDto;
import com.klu.Registration.Service.UserService;

@RestController
@CrossOrigin
@RequestMapping("register/user")
public class UserController {
	
	
	@Autowired
	private UserService userService;
	
	@PostMapping(path = "/save")
	public String saveUser(@RequestBody UserDto userDto)
	{
		String id = userService.addUser(userDto);
		return id;
	}

}
